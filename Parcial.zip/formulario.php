<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['tracking-number'])) {
        $trackingNumber = htmlspecialchars($_POST['tracking-number']);

        $trackingData = [
            "123456" => "En tránsito",
            "789012" => "Entregado",
            "345678" => "Pendiente de envío"
        ];

        $status = $trackingData[$trackingNumber] ?? "Número de seguimiento no encontrado";

        header('Content-Type: application/json');
        echo json_encode(["status" => "success", "trackingStatus" => $status]);
        exit();
    }

    $nombre = isset($_POST['nombre']) ? htmlspecialchars($_POST['nombre']) : "";
    $email = isset($_POST['email']) ? filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) : "";
    $asunto = isset($_POST['asunto']) ? htmlspecialchars($_POST['asunto']) : "";
    $mensaje = isset($_POST['mensaje']) ? htmlspecialchars($_POST['mensaje']) : "";
    
    $errores = array();
    
    if (empty($nombre)) {
        $errores[] = "El nombre es requerido";
    }
    
    if (empty($email)) {
        $errores[] = "El email es requerido";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El formato de email no es válido";
    }
    
    if (empty($asunto)) {
        $errores[] = "El asunto es requerido";
    }
    
    if (empty($mensaje)) {
        $errores[] = "El mensaje es requerido";
    }
    
    header('Content-Type: application/json');
    
    if (empty($errores)) {
        $respuesta = array(
            "status" => "success",
            "message" => "Gracias $nombre por contactarte por $asunto. Te responderemos pronto."
        );
        
        $log = "Fecha: " . date("Y-m-d H:i:s") . "\n";
        $log .= "Nombre: $nombre\n";
        $log .= "Email: $email\n";
        $log .= "Asunto: $asunto\n";
        $log .= "Mensaje: $mensaje\n";
        $log .= "------------------------------------\n";
        
        echo json_encode($respuesta);
    } else {
        $respuesta = array(
            "status" => "error",
            "errors" => $errores
        );
        echo json_encode($respuesta);
    }
} else {
    header("Location: index.html");
    exit();
}
?>