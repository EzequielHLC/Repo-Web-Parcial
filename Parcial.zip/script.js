document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const calculatorForm = document.getElementById('discount-form');
    const calculateBtn = document.getElementById('calculate-btn');
    const discountInput = document.getElementById('discount');
    const discountedPriceElement = document.getElementById('discounted-price');
    const contactForm = document.getElementById('contacto-form');
    const formResponse = document.getElementById('form-response');
    const navBar = document.getElementById('nav-bar');
    const trackingForm = document.querySelector('form');
    const trackingResults = document.getElementById('tracking-results');
    const trackingStatus = document.getElementById('tracking-status').querySelector('span');
    const basePrice = 15000;

    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            menuToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }

    if (calculateBtn) {
        calculateBtn.addEventListener('click', function() {
            const discountValue = parseFloat(discountInput.value) || 0;
            if (discountValue < 0 || discountValue > 100) {
                alert('Por favor ingresa un porcentaje válido entre 0 y 100');
                return;
            }
            const discountAmount = basePrice * (discountValue / 100);
            const finalPrice = basePrice - discountAmount;
            discountedPriceElement.textContent = `$${finalPrice.toFixed(0)}`;
            console.log(`Se ha calculado un descuento del ${discountValue}%. Precio final: $${finalPrice.toFixed(0)}`);
        });
    }

    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const nombre = document.getElementById('nombre').value.trim();
            const email = document.getElementById('email').value.trim();
            const asunto = document.getElementById('asunto').value.trim();
            const mensaje = document.getElementById('mensaje').value.trim();
            document.querySelectorAll('.error').forEach(el => el.textContent = '');
            let isValid = true;
            if (nombre === '') {
                document.getElementById('nombre-error').textContent = 'Por favor ingresa tu nombre';
                isValid = false;
            }
            if (email === '') {
                document.getElementById('email-error').textContent = 'Por favor ingresa tu email';
                isValid = false;
            } else if (!isValidEmail(email)) {
                document.getElementById('email-error').textContent = 'Por favor ingresa un email válido';
                isValid = false;
            }
            if (asunto === '') {
                document.getElementById('asunto-error').textContent = 'Por favor ingresa un asunto';
                isValid = false;
            }
            if (mensaje === '') {
                document.getElementById('mensaje-error').textContent = 'Por favor ingresa un mensaje';
                isValid = false;
            }
            if (isValid) {
                formResponse.classList.remove('hidden');
                formResponse.classList.remove('error');
                formResponse.textContent = `Gracias ${nombre} por contactarte por ${asunto}. Te responderemos pronto.`;
                console.log(`Gracias ${nombre} por contactarte por ${asunto}. Te responderemos pronto.`);
                contactForm.reset();
            }
        });
    }

    if (trackingForm) {
        trackingForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const trackingNumber = document.getElementById('tracking-number').value.trim();

            if (trackingNumber === '') {
                alert('Por favor ingresa un número de seguimiento.');
                return;
            }

            fetch('formulario.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({ 'tracking-number': trackingNumber })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    trackingResults.classList.remove('hidden');
                    trackingStatus.textContent = data.trackingStatus;
                } else {
                    alert('Error: ' + (data.errors || 'No se pudo obtener el estado del paquete.'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Hubo un problema al procesar tu solicitud.');
            });
        });
    }

    function isValidEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }

    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            navBar.style.backgroundColor = 'var(--primary-color)';
            navBar.style.boxShadow = 'var(--box-shadow)';
        } else {
            navBar.style.backgroundColor = 'var(--secondary-color)';
            navBar.style.boxShadow = 'none';
        }
    });
});